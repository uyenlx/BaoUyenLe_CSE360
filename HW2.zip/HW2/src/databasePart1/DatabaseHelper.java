package databasePart1;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import java.util.ArrayList;
import java.util.List;

import application.User;
import application.Question;
import application.Answer;


/**
 * The DatabaseHelper class is responsible for managing the connection to the database,
 * performing operations such as user registration, login validation, and handling invitation codes.
 */
public class DatabaseHelper {

	// JDBC driver name and database URL 
	static final String JDBC_DRIVER = "org.h2.Driver";   
	static final String DB_URL = "jdbc:h2:~/FoundationDatabase";  

	//  Database credentials 
	static final String USER = "sa"; 
	static final String PASS = ""; 

	private Connection connection = null;
	private Statement statement = null; 
	//	PreparedStatement pstmt

	public void connectToDatabase() throws SQLException {
		try {
			Class.forName(JDBC_DRIVER); // Load the JDBC driver
			System.out.println("Connecting to database...");
			connection = DriverManager.getConnection(DB_URL, USER, PASS);
			statement = connection.createStatement(); 
			// You can use this command to clear the database and restart from fresh.
			//statement.execute("DROP ALL OBJECTS");

			createTables();  // Create the necessary tables if they don't exist
		} catch (ClassNotFoundException e) {
			System.err.println("JDBC Driver not found: " + e.getMessage());
		}
	}

	private void createTables() throws SQLException {
		String userTable = "CREATE TABLE IF NOT EXISTS cse360users ("
				+ "id INT AUTO_INCREMENT PRIMARY KEY, "
				+ "userName VARCHAR(255) UNIQUE, "
				+ "password VARCHAR(255), "
				+ "role VARCHAR(255))";
		statement.execute(userTable);
		
		// Create the invitation codes table
	    String invitationCodesTable = "CREATE TABLE IF NOT EXISTS InvitationCodes ("
	            + "code VARCHAR(10) PRIMARY KEY, "
	            + "isUsed BOOLEAN DEFAULT FALSE)";
	    statement.execute(invitationCodesTable);
	    
	
	    
	    //Create Questions table
	String questionsTable = "CREATE TABLE IF NOT EXISTS Questions ("
		    + "questionId INT AUTO_INCREMENT PRIMARY KEY, "
		    + "userName VARCHAR(255), "
		    + "title VARCHAR(255), "
		    + "content CLOB, "
		    + "isResolved BOOLEAN DEFAULT FALSE, "
		    + "postedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
		    + "FOREIGN KEY (userName) REFERENCES cse360users(userName))";
		statement.execute(questionsTable);

		// Answers table
		String answersTable = "CREATE TABLE IF NOT EXISTS Answers ("
		    + "answerId INT AUTO_INCREMENT PRIMARY KEY, "
		    + "questionId INT, "
		    + "userName VARCHAR(255), "
		    + "title VARCHAR(255), "
		    + "content CLOB, "
		    + "isResolved BOOLEAN DEFAULT FALSE, "
		    + "postedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
		    + "FOREIGN KEY (questionId) REFERENCES Questions(questionId) ON DELETE CASCADE, "
		    + "FOREIGN KEY (userName) REFERENCES cse360users(userName))";
		statement.execute(answersTable);
	}
	public List<Question> getAllQuestions() {
	    List<Question> questions = new ArrayList<>();
	    String sql = "SELECT * FROM Questions ORDER BY questionId ASC"; // or DESC if you want newest first
	    try (PreparedStatement ps = connection.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {
	        while (rs.next()) {
	            int id = rs.getInt("questionId");
	            String title = rs.getString("title");
	            String content = rs.getString("content");
	            String userName = rs.getString("userName");
	            User user = new User(userName);
	            questions.add(new Question(id, user, title, content));
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return questions;
	}
	public List<Answer> getAnswersForQuestion(int questionId) {
	    List<Answer> answers = new ArrayList<>();
	    String sql = "SELECT * FROM Answers WHERE questionId = ? ORDER BY postedAt ASC";

	    try (PreparedStatement ps = connection.prepareStatement(sql)) {
	        ps.setInt(1, questionId);
	        try (ResultSet rs = ps.executeQuery()) {
	            while (rs.next()) {
	                int answerId = rs.getInt("answerId");
	                String content = rs.getString("content");
	                String userName = rs.getString("userName");
	                User user = new User(userName);  // create a User object with the correct username
	                answers.add(new Answer(answerId, questionId, user, content));
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return answers;
	}

	public List<Answer> getAllAnswers() {
	    List<Answer> answers = new ArrayList<>();
	    String sql = "SELECT * FROM Answers ORDER BY postedAt ASC";

	    try (PreparedStatement ps = connection.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {
	        while (rs.next()) {
	            int answerId = rs.getInt("answerId");
	            int questionId = rs.getInt("questionId");
	            String content = rs.getString("content");
	            String userName = rs.getString("userName");
	            User user = new User(userName); 
	            answers.add(new Answer(answerId, questionId, user, content));
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return answers;
	}
	
	
	public void addQuestion(Question question) {
	    String sql = "INSERT INTO Questions (userName, title, content) VALUES (?, ?, ?)";
	    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
	        pstmt.setString(1, question.getUser().getUserName());
	        pstmt.setString(2, question.getTitle());
	        pstmt.setString(3, question.getContent());
	        pstmt.executeUpdate();
	        System.out.println("Question added");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	public void addAnswer(int questionId, User user, String content) {
	    String sql = "INSERT INTO Answers (questionId, userName, content, postedAt) VALUES (?, ?, ?, ?)";
	    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
	        stmt.setInt(1, questionId);
	        stmt.setString(2, user.getUserName());
	        stmt.setString(3, content);
	        stmt.setString(4, java.time.LocalDateTime.now().toString());
	        stmt.executeUpdate();
	        System.out.println("Answer added successfully for question " + questionId);
	    } catch (SQLException e) {
	        System.out.println("Error adding answer: " + e.getMessage());
	    }
	}
	public void deleteQuestion(int questionId) {
	    String sql = "DELETE FROM Questions WHERE questionId = ?";
	    try (PreparedStatement ps = connection.prepareStatement(sql)) {
	        ps.setInt(1, questionId);
	        ps.executeUpdate();
	        System.out.println("Deleted question " + questionId);
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	public void deleteAnswer(int answerId) {
	    String sql = "DELETE FROM Answers WHERE answerId = ?";
	    try (PreparedStatement ps = connection.prepareStatement(sql)) {
	        ps.setInt(1, answerId);
	        ps.executeUpdate();
	        System.out.println("Deleted answer " + answerId);
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}




	
	
	

	
	
	

	// Check if the database is empty
	public boolean isDatabaseEmpty() throws SQLException {
		String query = "SELECT COUNT(*) AS count FROM cse360users";
		ResultSet resultSet = statement.executeQuery(query);
		if (resultSet.next()) {
			return resultSet.getInt("count") == 0;
		}
		return true;
	}

	// Registers a new user in the database.
	public void register(User user) throws SQLException {
		if (isDatabaseEmpty() ) {
			user.setRole("admin");
		}
		else {
			user.setRole("student");
		}
		String insertUser = "INSERT INTO cse360users (userName, password, role) VALUES (?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(insertUser)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getRolesSummary().replace(" ", ","));
			pstmt.executeUpdate();
		}
	}

	// Validates a user's login credentials.
	public boolean login(User user) throws SQLException {
	    String query = "SELECT * FROM cse360users WHERE userName = ? AND password = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, user.getUserName());
	        pstmt.setString(2, user.getPassword());
	        try (ResultSet rs = pstmt.executeQuery()) {
	            if (rs.next()) {
	                // Load roles from DB (comma-separated)
	                String roles = rs.getString("role");
	                if (roles != null && !roles.isEmpty()) {
	                    for (String r : roles.split(",")) {
	                        user.setRole(r.trim());
	                    }
	                }
	                return true;
	            }
	        }
	    }
	    return false;
	}
	
	// Checks if a user already exists in the database based on their userName.
	public boolean doesUserExist(String userName) {
	    String query = "SELECT COUNT(*) FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            // If the count is greater than 0, the user exists
	            return rs.getInt(1) > 0;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false; // If an error occurs, assume user doesn't exist
	}
	
	// Retrieves the role of a user from the database using their UserName.
	public String getUserRole(String userName) {
	    String query = "SELECT role FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("role"); // Return the role if user exists
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null; // If no user exists or an error occurs
	}
	// Updates the roles of a user in the database
	public void updateUserRoles(User user) {
	    String query = "UPDATE cse360users SET role = ? WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, user.getRolesSummary().replace(" ", ",")); // store as comma-separated
	        pstmt.setString(2, user.getUserName());
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	//Load roles individually
	public void loadUserRoles(User user) {
	    String query = "SELECT role FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, user.getUserName());
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            String roles = rs.getString("role");
	            if (roles != null && !roles.isEmpty()) {
	                for (String r : roles.split(",")) {
	                    user.setRole(r.trim()); // set each role individually
	                }
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	// Generates a new invitation code and inserts it into the database.
	public String generateInvitationCode() {
	    String code = UUID.randomUUID().toString().substring(0, 4); // Generate a random 4-character code
	    String query = "INSERT INTO InvitationCodes (code) VALUES (?)";

	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return code;
	}
	
	// Validates an invitation code to check if it is unused.
	public boolean validateInvitationCode(String code) {
	    String query = "SELECT * FROM InvitationCodes WHERE code = ? AND isUsed = FALSE";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            // Mark the code as used
	            markInvitationCodeAsUsed(code);
	            return true;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}
	
	// Marks the invitation code as used in the database.
	private void markInvitationCodeAsUsed(String code) {
	    String query = "UPDATE InvitationCodes SET isUsed = TRUE WHERE code = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	// Closes the database connection and statement.
	public void closeConnection() {
		try{ 
			if(statement!=null) statement.close(); 
		} catch(SQLException se2) { 
			se2.printStackTrace();
		} 
		try { 
			if(connection!=null) connection.close(); 
		} catch(SQLException se){ 
			se.printStackTrace(); 
		} 
	}

	

}
