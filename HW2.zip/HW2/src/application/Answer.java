package application;

import java.time.LocalDateTime;

/**
 * Answer represents a user's response to a specific question.
 */
public class Answer {
    private int answerId;
    private int questionId;   // Links this answer to its question
    private User user;        // The author
    private String content;   // The text of the answer
    private boolean isResolved;
    private LocalDateTime postedAt;

    public Answer(int answerId, int questionId, User user, String content) {
        this.answerId = answerId;
        this.questionId = questionId;
        this.user = user;
        this.content = content;
        this.isResolved = false;
        this.postedAt = LocalDateTime.now();
    }

    // Getters
    public int getAnswerId() {
        return answerId;
    }

    public int getQuestionId() {
        return questionId;
    }

    public User getUser() {
        return user;
    }

    public String getContent() {
        return content;
    }

    public boolean isResolved() {
        return isResolved;
    }

    public LocalDateTime getPostedAt() {
        return postedAt;
    }

    // Setters
    public void editAnswer(String newContent) {
        this.content = newContent;
    }

    public void markResolved() {
        this.isResolved = true;
    }
}