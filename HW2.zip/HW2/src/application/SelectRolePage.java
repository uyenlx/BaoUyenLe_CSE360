package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import databasePart1.*;

/**
 * Page where the user can add/remove roles.
 */
public class SelectRolePage {

    private final DatabaseHelper databaseHelper;

    public SelectRolePage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage, User user) {
    	//Labels
        Label headerLabel = new Label("Welcome, " + user.getUserName() + "!");
        Label currentRolesLabel = new Label("Current Roles: " + user.getRolesSummary());
        //Drop-down choice box to determine what home page user wants to access
        ChoiceBox<String> roleChoice = new ChoiceBox<>();
        roleChoice.getItems().addAll("student", "reviewer", "instructor", "staff");
        roleChoice.setValue("student");
        //Buttons
        Button addRoleButton = new Button("Add Role");
        Button removeRoleButton = new Button("Remove Role");
        Button continueButton = new Button("Continue");
        Button backButton = new Button("Back");
        //Add roles for users
        addRoleButton.setOnAction(e -> {
            String role = roleChoice.getValue();
            user.setRole(role);
            databaseHelper.updateUserRoles(user);
            currentRolesLabel.setText("Current Roles: " + user.getRolesSummary());
        });
        //Remove roles for users
        removeRoleButton.setOnAction(e -> {
            String role = roleChoice.getValue();
            user.removeRole(role);
            databaseHelper.updateUserRoles(user);
            currentRolesLabel.setText("Current Roles: " + user.getRolesSummary());
        });
        
        continueButton.setOnAction(e -> {
            new WelcomeLoginPage(databaseHelper).show(primaryStage, user);
        });
        
        backButton.setOnAction(e->{
        	new WelcomeLoginPage(databaseHelper).show(primaryStage, user);
        });

        VBox layout = new VBox(10, headerLabel, currentRolesLabel, roleChoice, addRoleButton, removeRoleButton, continueButton, backButton);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        primaryStage.setScene(new Scene(layout, 800, 400));
        primaryStage.setTitle("Select Roles");
        primaryStage.show();
    }
}