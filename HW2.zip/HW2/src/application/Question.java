package application;

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;
/**
 * Question contains content of the question, title, author, and answers given
 */

public class Question{
	private int questionId;
	private User user;
	private String title;
	private String content;
	private List<Integer> answerIds;
	private boolean isResolved;
	private LocalDateTime postedAt;
	
	public Question(int questionId, User user, String title, String content) {
		this.questionId = questionId;
		this.user = user;
		this.title = title;
		this.content = content;
		//question automatically posted as not resolved
		this.isResolved = false;
		this.postedAt = LocalDateTime.now();
		this.answerIds = new ArrayList<>();
	}
	
	
	
	//Getters
	public int getQuestionId() {
		return this.questionId;
	}
	public String getContent() {
		return this.content;
	}
	public User getUser() {
		return this.user;
	}
	public String getTitle() {
		return this.title;
	}
	
	public LocalDateTime getPostedAt() {
		return this.postedAt;
	}
	public List<Integer> getAnswerIds(){
		return new ArrayList<>(this.answerIds);
	}
	
	//Setters
	public void editQuestion(String content) {
		this.content = content;
	}
	
	public void markResolved() {
		this.isResolved = true;
	}
}