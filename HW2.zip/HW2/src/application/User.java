package application;

/**
 * The User class represents a user entity in the system.
 * It contains the user's details such as userName, password, and role.
 */
public class User {
	//adding booleans to check roles
    private String userName;
    private String password;
    private String role;
    private boolean isAdmin;
    private boolean isStudent;
    private boolean isInstructor;
    private boolean isReviewer;
    private boolean isStaff;
    

    // Constructor to initialize a new User object with userName, password, and role.
    public User( String userName, String password, String role) {
        this.userName = userName;
        this.password = password;
        setRole(role);
    }
    
    public User(String userName) {
    	this.userName = userName;
    }
    
    // Sets the role of the user.
    public String setRole(String role) {
    	switch (role.toLowerCase()) {
    	case "admin":
    		isAdmin = true;
    		return "OK";
    	case "student":
    		isStudent = true;
    		return "OK";
    	case "instructor":
    		isInstructor = true;
    	case "reviewer":
    		isReviewer = true;
    		return "OK";
    	case "staff":
    		isStaff = true;
    		return "OK";
    		default: return "user";
    	}
    }
    //remove role method
    public String removeRole(String role) {
    	switch (role.toLowerCase()) {
    	case "admin":
    		isAdmin = true;
    		return "OK";
    	case "student":
    		isStudent = false;
    		return "OK";
    	case "instructor":
    		isInstructor = false;
    	case "reviewer":
    		isReviewer = false;
    		return "OK";
    	case "staff":
    		isStaff = false;
    		return "OK";
    		default: return "user";
    	}
    }
    //Returns all roles user is
    public String getRolesSummary() {
        StringBuilder sb = new StringBuilder();
        if (isAdmin) sb.append("Admin ");
        if (isStudent) sb.append("Student ");
        if (isReviewer) sb.append("Reviewer ");
        if (isInstructor) sb.append("Instructor ");
        if (isStaff) sb.append("Staff ");
        return sb.length() > 0 ? sb.toString().trim() : "No roles";
    }
    //return role
    public String getRole() {
        int count = 0;
        String lastRole = "";
        if (isAdmin) { count++; lastRole = "admin"; }
        if (isStudent) { count++; lastRole = "student"; }
        if (isReviewer) { count++; lastRole = "reviewer"; }
        if (isInstructor) { count++; lastRole = "instructor"; }
        if (isStaff) { count++; lastRole = "staff"; }
        return count == 1 ? lastRole : "many";
    }
    
    //Getters
    public String getUserName() { return userName; }
    public String getPassword() { return password; }
  
    public boolean isAdmin() { return isAdmin; }
    public boolean isStudent() { return isStudent; }
    public boolean isReviewer() { return isReviewer; }
    public boolean isInstructor() { return isInstructor; }
    public boolean isStaff() { return isStaff; }
}
