package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * This page displays a simple welcome message for the user.
 */

public class ReviewerHomePage {
	private final DatabaseHelper databaseHelper;
	private final User user;
    public ReviewerHomePage(DatabaseHelper databaseHelper, User user) {
        this.databaseHelper = databaseHelper;
        this.user =  user;
    }

    public void show(Stage primaryStage) {
    	VBox layout = new VBox();
	    layout.setStyle("-fx-alignment: center; -fx-padding: 20;");
	    
	    // Label to display Hello user
	    Label userLabel = new Label("Hello, Reviewer!");
	    userLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
	    
	    //Logout Button
	    Button logoutButton = new Button("Log Out");
	    
	    logoutButton.setOnAction(a->{
	    	new SetupLoginSelectionPage(databaseHelper).show(primaryStage);
	    });
	    
	    //Back Button
	    Button backButton = new Button("Back");
	    
	    backButton.setOnAction(a -> {
	    	new WelcomeLoginPage(databaseHelper).show(primaryStage,user);
	    });

	    //changed to addAll to add multiple elements
	    layout.getChildren().addAll(userLabel,logoutButton,backButton);
	    Scene userScene = new Scene(layout, 800, 400);
	    
	    

	    // Set the scene to primary stage
	    primaryStage.setScene(userScene);
	    primaryStage.setTitle("Reviewer Page");
    	
    }
}