package application;

import java.util.List;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


/**
 * AdminPage class represents the user interface for the admin user.
 * This page displays a simple welcome message for the admin.
 */

public class AdminHomePage {
	/**
     * Displays the admin page in the provided primary stage.
     * @param primaryStage The primary stage where the scene will be displayed.
     */
	//use databaseHelper
	private final DatabaseHelper databaseHelper;
	private final User userAdmin;
    public AdminHomePage(DatabaseHelper databaseHelper, User userAdmin) {
        this.databaseHelper = databaseHelper;
        this.userAdmin =  userAdmin;
    }
    public void show(Stage primaryStage, User user) {
    	
    	
    	
    	VBox layout = new VBox();
    	
	    layout.setStyle("-fx-alignment: center; -fx-padding: 20;");
	    
	    // label to display the welcome message for the admin
	    Label adminLabel = new Label("Hello, Admin!");
	    
	    //view for username list
	    ListView<String> userList = new ListView<>();
	    userList.setStyle("-fx-alignment: left; -fx-padding: 20;");
	    userList.setPrefSize(700,400);
	    
	    Button backButton = new Button("Back");
	    
	    backButton.setOnAction(a -> {
	    	new WelcomeLoginPage(databaseHelper).show(primaryStage,user);
	    });
	    //Navigate to QuestionsPage
	    Button questionButton = new Button("Questions");
	    questionButton.setOnAction(e-> {
	    	new QuestionsPage(databaseHelper, user).show(primaryStage);
	    });
	    
	  //Logout Button
	    Button logoutButton = new Button("Log Out");
	    
	    logoutButton.setOnAction(a->{
	    	new SetupLoginSelectionPage(databaseHelper).show(primaryStage);
	    });
	    
	    
	    
	    adminLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

	    //changed to addAll
	    layout.getChildren().addAll(adminLabel, questionButton, backButton, logoutButton);
	    Scene adminScene = new Scene(layout, 800, 400);

	    // Set the scene to primary stage
	    primaryStage.setScene(adminScene);
	    primaryStage.setTitle("Admin Page");
    }
}