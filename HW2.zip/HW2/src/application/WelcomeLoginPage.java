package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.application.Platform;
import databasePart1.*;

/**
 * The WelcomeLoginPage class displays a welcome screen for authenticated users.
 * It allows users to choose which role to continue as, or manage their roles.
 */
public class WelcomeLoginPage {

    private final DatabaseHelper databaseHelper;

    public WelcomeLoginPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage, User user) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Label welcomeLabel = new Label("Welcome, " + user.getUserName() + "!");
        Label roleLabel = new Label("Your roles: " + user.getRolesSummary());

        // Role selection box (if multiple roles)
        ChoiceBox<String> roleChoice = new ChoiceBox<>();
        if (user.isAdmin()) roleChoice.getItems().add("admin");
        if (user.isStudent()) roleChoice.getItems().add("student");
        if (user.isReviewer()) roleChoice.getItems().add("reviewer");
        if (user.isInstructor()) roleChoice.getItems().add("instructor");
        if (user.isStaff()) roleChoice.getItems().add("staff");

        if (!roleChoice.getItems().isEmpty()) {
            roleChoice.setValue(roleChoice.getItems().get(0));
        }

        Button continueButton = new Button("Continue to Page");
        continueButton.setOnAction(a -> {
            String selectedRole = roleChoice.getValue();
            switch (selectedRole) {
                case "admin":
                    new AdminHomePage(databaseHelper, user).show(primaryStage, user);
                    break;
                case "student":
                    new UserHomePage(databaseHelper, user).show(primaryStage);
                    break;
                case "reviewer":
                    new ReviewerHomePage(databaseHelper, user).show(primaryStage);
                    break;
                case "instructor":
                    new InstructorHomePage(databaseHelper, user).show(primaryStage);
                    break;
                case "staff":
                    new StaffHomePage(databaseHelper, user).show(primaryStage);
                    break;
            }
        });

        Button editRolesButton = new Button("Edit Roles");
        editRolesButton.setOnAction(a -> {
            new SelectRolePage(databaseHelper).show(primaryStage, user);
        });

        Button logoutButton = new Button("Log Out");
        logoutButton.setOnAction(a -> {
            new SetupLoginSelectionPage(databaseHelper).show(primaryStage);
        });

        Button quitButton = new Button("Quit");
        quitButton.setOnAction(a -> {
            databaseHelper.closeConnection();
            Platform.exit
            ();
        });
        layout.getChildren().addAll(welcomeLabel, roleLabel);
        if (user.getRolesSummary().contains("Admin")) {
            Button inviteButton = new Button("Invite");
            inviteButton.setOnAction(a -> {
                new InvitationPage(databaseHelper, user).show(databaseHelper, primaryStage, user);
            });
            layout.getChildren().add(inviteButton);
        }
        layout.getChildren().addAll(roleChoice, continueButton, editRolesButton, logoutButton, quitButton);
        
        Scene scene = new Scene(layout, 800, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Welcome Page");
        primaryStage.show();
    }
}