package application;

import databasePart1.DatabaseHelper;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;

public class QuestionsPage {

    private final DatabaseHelper databaseHelper;
    private final User user;

    public QuestionsPage(DatabaseHelper databaseHelper, User user) {
        this.databaseHelper = databaseHelper;
        this.user = user;
    }

    public void show(Stage primaryStage) {
        VBox rootLayout = new VBox(15);
        rootLayout.setPadding(new Insets(20));

        Label titleLabel = new Label("Questions Forum");
        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        Accordion accordion = new Accordion();
        loadQuestions(accordion);

        Button postQuestionBtn = new Button("Post a Question");
        postQuestionBtn.setOnAction(e -> openPostQuestionWindow(accordion));

        Button postAnswerBtn = new Button("Post an Answer");
        postAnswerBtn.setOnAction(e -> openPostAnswerWindow(accordion));

        Button backBtn = new Button("Back");
        backBtn.setOnAction(e -> new WelcomeLoginPage(databaseHelper).show(primaryStage, user));

        rootLayout.getChildren().addAll(titleLabel, accordion, postQuestionBtn, postAnswerBtn, backBtn);

        Scene scene = new Scene(rootLayout, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Questions Forum");
    }

    /** Load all questions from the database into the Accordion */
    private void loadQuestions(Accordion accordion) {
        accordion.getPanes().clear();
        List<Question> questions = databaseHelper.getAllQuestions();
        System.out.println("Loading " + questions.size() + " questions");

        for (Question q : questions) {
            TitledPane pane = createQuestionPane(q, accordion);
            accordion.getPanes().add(pane);
        }
    }

    /** Create a TitledPane for a single question */
    private TitledPane createQuestionPane(Question q, Accordion accordion) {
        VBox contentBox = new VBox(10);
        contentBox.setPadding(new Insets(10));

        Label questionIdLabel = new Label("Question ID: " + q.getQuestionId());
        Label questionContent = new Label(q.getContent());

        // Delete Question
        Button deleteQuestionBtn = new Button("Delete Question");
        deleteQuestionBtn.setOnAction(e -> {
            databaseHelper.deleteQuestion(q.getQuestionId());
            loadQuestions(accordion);
        });

        // Answers Section
        VBox answersBox = new VBox(5);
        loadAnswers(answersBox, q.getQuestionId());

        // Refresh Answers
        Button refreshAnswersBtn = new Button("Refresh Answers");
        refreshAnswersBtn.setOnAction(e -> loadAnswers(answersBox, q.getQuestionId()));

        contentBox.getChildren().addAll(
                questionIdLabel, questionContent,
                deleteQuestionBtn, refreshAnswersBtn, answersBox
        );

        TitledPane pane = new TitledPane(
                "[" + q.getQuestionId() + "] " + q.getTitle() + " by " + q.getUser().getUserName(),
                contentBox
        );
        pane.setExpanded(false);
        return pane;
    }

    /** Load all answers for a given question into the VBox */
    private void loadAnswers(VBox answersBox, int questionId) {
        answersBox.getChildren().clear();
        List<Answer> answers = databaseHelper.getAnswersForQuestion(questionId);

        for (Answer a : answers) {
            VBox answerRow = new VBox(5);
            Label answerLabel = new Label(a.getUser().getUserName() + ": " + a.getContent());

            // Delete Answer
            Button deleteAnswerBtn = new Button("Delete Answer");
            deleteAnswerBtn.setOnAction(e -> {
                databaseHelper.deleteAnswer(a.getAnswerId());
                answersBox.getChildren().remove(answerRow);
            });

            answerRow.getChildren().addAll(answerLabel, deleteAnswerBtn);
            answerRow.setStyle("-fx-padding: 5; -fx-border-color: lightgray; -fx-border-width: 0 0 1 0;");
            answersBox.getChildren().add(answerRow);
        }
    }

    /** Open window to post a new question */
    private void openPostQuestionWindow(Accordion accordion) {
        Stage stage = new Stage();
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        Label titleLabel = new Label("Title:");
        TextField titleField = new TextField();

        Label contentLabel = new Label("Content:");
        TextArea contentArea = new TextArea();
        contentArea.setPrefRowCount(5);

        Button submitBtn = new Button("Submit Question");
        Label feedback = new Label();

        submitBtn.setOnAction(e -> {
            String title = titleField.getText().trim();
            String content = contentArea.getText().trim();

            if (title.isEmpty() || content.isEmpty()) {
                feedback.setText("Please fill in all fields.");
                return;
            }

            Question question = new Question(0, user, title, content);
            databaseHelper.addQuestion(question);

            feedback.setText("Question posted.");
            titleField.clear();
            contentArea.clear();

            loadQuestions(accordion); // refresh Accordion
        });

        layout.getChildren().addAll(titleLabel, titleField, contentLabel, contentArea, submitBtn, feedback);
        stage.setScene(new Scene(layout, 400, 300));
        stage.show();
    }

    /** Open window to post a new answer */
    private void openPostAnswerWindow(Accordion accordion) {
        Stage stage = new Stage();
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        Label idLabel = new Label("Question ID:");
        TextField idField = new TextField();

        Label answerLabel = new Label("Answer:");
        TextArea answerArea = new TextArea();
        answerArea.setPrefRowCount(5);

        Button submitBtn = new Button("Submit Answer");
        Label feedback = new Label();

        submitBtn.setOnAction(e -> {
            try {
                int questionId = Integer.parseInt(idField.getText().trim());
                String content = answerArea.getText().trim();

                if (content.isEmpty()) {
                    feedback.setText("Please enter an answer.");
                    return;
                }

                databaseHelper.addAnswer(questionId, user, content);
                feedback.setText("Answer posted.");
                idField.clear();
                answerArea.clear();

                loadQuestions(accordion); // refresh Accordion

            } catch (NumberFormatException ex) {
                feedback.setText("Question ID must be a number.");
            }
        });

        layout.getChildren().addAll(idLabel, idField, answerLabel, answerArea, submitBtn, feedback);
        stage.setScene(new Scene(layout, 400, 300));
        stage.show();
    }
}
